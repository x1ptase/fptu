let option = document.getElementById("tour");

function tourChoose(){
    let price = option.options[option.selectedIndex].value;
    document.getElementById("price").textContent= price+"$/Person"
}

function CalTotal(){
    let price = option.options[option.selectedIndex].value; // 150
    let number = document.getElementById("number").value;
    let total = price * number;

    document.getElementById("total").textContent="Total amount: "+total+"$";
}
