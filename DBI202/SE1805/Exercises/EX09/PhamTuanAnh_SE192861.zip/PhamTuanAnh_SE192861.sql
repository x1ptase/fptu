﻿USE QLBanHang;
GO

-- Stored Procedure 1: sp_ThemNhaCungCap
CREATE PROCEDURE sp_ThemNhaCungCap
    @MaNCC VARCHAR(5),
    @TenNCC NVARCHAR(50),
    @DiaChi NVARCHAR(50),
    @DienThoai VARCHAR(12)
AS
BEGIN
   
    IF EXISTS (SELECT 1 FROM NHACUNGCAP WHERE MaNCC = @MaNCC)
    BEGIN
        RAISERROR ('Mã nhà cung cấp đã tồn tại!', 16, 1);
        RETURN;
    END

    INSERT INTO NHACUNGCAP (MaNCC, TenNCC, DiaChi, DienThoai)
    VALUES (@MaNCC, @TenNCC, @DiaChi, @DienThoai);
END;
GO

-- Stored Procedure 2: sp_ThemPhieuNhap
CREATE PROCEDURE sp_ThemPhieuNhap
    @SoPN VARCHAR(5),
    @NgayNhap DATE,
    @SoDH VARCHAR(5),
    @MaVT VARCHAR(5),
    @SLNhap INT,
    @DGNhap INT
AS
BEGIN
  
    BEGIN TRY
        BEGIN TRANSACTION;
        
        IF EXISTS (SELECT 1 FROM PHIEUNHAP WHERE SoPN = @SoPN)
        BEGIN
            RAISERROR ('Số phiếu nhập đã tồn tại!', 16, 1);
            ROLLBACK;
            RETURN;
        END
        
        IF NOT EXISTS (SELECT 1 FROM DONDATHANG WHERE SoDH = @SoDH)
        BEGIN
            RAISERROR ('Số đơn đặt hàng không tồn tại!', 16, 1);
            ROLLBACK;
            RETURN;
        END
      
        IF NOT EXISTS (SELECT 1 FROM VATTU WHERE MaVT = @MaVT)
        BEGIN
            RAISERROR ('Mã vật tư không tồn tại!', 16, 1);
            ROLLBACK;
            RETURN;
        END
        
        INSERT INTO PHIEUNHAP (SoPN, NgayNhap, SoDH)
        VALUES (@SoPN, @NgayNhap, @SoDH);
       
        INSERT INTO CTPHIEUNHAP (SoPN, MaVT, SLNhap, DGNhap)
        VALUES (@SoPN, @MaVT, @SLNhap, @DGNhap);
        
        COMMIT;
    END TRY
    BEGIN CATCH
        ROLLBACK;
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR (@ErrorMessage, 16, 1);
    END CATCH;
END;
GO

-- Stored Procedure 3: sp_XoaPhieuXuat

CREATE PROCEDURE sp_XoaPhieuXuat
    @SoPX VARCHAR(5)
AS
BEGIN
  
    BEGIN TRY
        BEGIN TRANSACTION;
        
        
        IF NOT EXISTS (SELECT 1 FROM PHIEUXUAT WHERE SoPX = @SoPX)
        BEGIN
            RAISERROR ('Số phiếu xuất không tồn tại!', 16, 1);
            ROLLBACK;
            RETURN;
        END
       
        DELETE FROM CTPHIEUXUAT WHERE SoPX = @SoPX;
      
        DELETE FROM PHIEUXUAT WHERE SoPX = @SoPX;
        
        COMMIT;
    END TRY
    BEGIN CATCH
        ROLLBACK;
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR (@ErrorMessage, 16, 1);
    END CATCH;
END;
GO

-- Stored Procedure 4: sp_ThongKeNhapTheoNhaCungCap

CREATE PROCEDURE sp_ThongKeNhapTheoNhaCungCap
AS
BEGIN
    SELECT 
        NCC.MaNCC,
        NCC.TenNCC,
        SUM(CTPN.SLNhap) AS TongSoLuongNhap,
        SUM(CTPN.SLNhap * CTPN.DGNhap) AS TongTienNhap
    FROM NHACUNGCAP NCC
    JOIN DONDATHANG DH ON NCC.MaNCC = DH.MaNCC
    JOIN PHIEUNHAP PN ON DH.SoDH = PN.SoDH
    JOIN CTPHIEUNHAP CTPN ON PN.SoPN = CTPN.SoPN
    GROUP BY NCC.MaNCC, NCC.TenNCC;
END;
GO

-- Test sp_ThemNhaCungCap
EXEC sp_ThemNhaCungCap 'C08', N'Nguyễn Văn A', N'123 Trần Phú, HCM', '12345678';
SELECT * FROM NHACUNGCAP WHERE MaNCC = 'C08';
GO

-- Test sp_ThemPhieuNhap
EXEC sp_ThemPhieuNhap 'N005', '2025-07-11', 'D001', 'DD01', 5, 2500000;
SELECT * FROM PHIEUNHAP WHERE SoPN = 'N005';
SELECT * FROM CTPHIEUNHAP WHERE SoPN = 'N005';
GO

-- Test sp_XoaPhieuXuat
EXEC sp_XoaPhieuXuat 'X001';
SELECT * FROM PHIEUXUAT WHERE SoPX = 'X001';
SELECT * FROM CTPHIEUXUAT WHERE SoPX = 'X001';
GO

-- Test sp_ThongKeNhapTheoNhaCungCap
EXEC sp_ThongKeNhapTheoNhaCungCap;
GO