﻿-- Question 1: Create view vw_CTPNHAP
CREATE VIEW vw_CTPNHAP AS
SELECT 
    SoPN,
    MaVT,
    SLNhap,
    DGNhap,
    (SLNhap * DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP;
GO

-- Question 2: Create view vw_CTPNHAP_VT
CREATE VIEW vw_CTPNHAP_VT AS
SELECT 
    CTPN.SoPN,
    CTPN.MaVT,
    VT.TenVT,
    CTPN.SLNhap,
    CTPN.DGNhap,
    (CTPN.SLNhap * CTPN.DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP CTPN
JOIN VATTU VT ON CTPN.MaVT = VT.MaVT;
GO

-- Question 3: Create view vw_CTPNHAP_VT_PN
CREATE VIEW vw_CTPNHAP_VT_PN AS
SELECT 
    CTPN.SoPN,
    PN.NgayNhap,
    PN.SoDH,
    CTPN.MaVT,
    VT.TenVT,
    CTPN.SLNhap,
    CTPN.DGNhap,
    (CTPN.SLNhap * CTPN.DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP CTPN
JOIN PHIEUNHAP PN ON CTPN.SoPN = PN.SoPN
JOIN VATTU VT ON CTPN.MaVT = VT.MaVT;
GO

-- Question 4: Create view vw_CTPNHAP_VT_PN_DH
CREATE VIEW vw_CTPNHAP_VT_PN_DH AS
SELECT 
    CTPN.SoPN,
    PN.NgayNhap,
    PN.SoDH,
    DH.MaNCC,
    CTPN.MaVT,
    VT.TenVT,
    CTPN.SLNhap,
    CTPN.DGNhap,
    (CTPN.SLNhap * CTPN.DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP CTPN
JOIN PHIEUNHAP PN ON CTPN.SoPN = PN.SoPN
JOIN DONDATHANG DH ON PN.SoDH = DH.SoDH
JOIN VATTU VT ON CTPN.MaVT = VT.MaVT;
GO

-- Question 5: Create view vw_CTPNHAP_loc
CREATE VIEW vw_CTPNHAP_loc AS
SELECT 
    SoPN,
    MaVT,
    SLNhap,
    DGNhap,
    (SLNhap * DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP
WHERE SLNhap > 5;
GO

-- Question 6: Create view vw_CTPNHAP_VT_loc
CREATE VIEW vw_CTPNHAP_VT_loc AS
SELECT 
    CTPN.SoPN,
    CTPN.MaVT,
    VT.TenVT,
    CTPN.SLNhap,
    CTPN.DGNhap,
    (CTPN.SLNhap * CTPN.DGNhap) AS ThanhTienNhap
FROM CTPHIEUNHAP CTPN
JOIN VATTU VT ON CTPN.MaVT = VT.MaVT
WHERE VT.DonViTinh = N'Bộ';
GO

-- Question 7: Create view vw_CTPXUAT
CREATE VIEW vw_CTPXUAT AS
SELECT 
    SoPX,
    MaVT,
    SoLuong,
    DGXuat,
    (SoLuong * DGXuat) AS ThanhTienXuat
FROM CTPHIEUXUAT;
GO

-- Question 8: Create view vw_CTPXUAT_VT
CREATE VIEW vw_CTPXUAT_VT AS
SELECT 
    CTPX.SoPX,
    CTPX.MaVT,
    VT.TenVT,
    CTPX.SoLuong,
    CTPX.DGXuat
FROM CTPHIEUXUAT CTPX
JOIN VATTU VT ON CTPX.MaVT = VT.MaVT;
GO

-- Question 9: Create view vw_CTPXUAT_VT_PX
CREATE VIEW vw_CTPXUAT_VT_PX AS
SELECT 
    CTPX.SoPX,
    PX.TenKH,
    CTPX.MaVT,
    VT.TenVT,
    CTPX.SoLuong,
    CTPX.DGXuat
FROM CTPHIEUXUAT CTPX
JOIN PHIEUXUAT PX ON CTPX.SoPX = PX.SoPX
JOIN VATTU VT ON CTPX.MaVT = VT.MaVT;
GO

-- Verification queries (optional, for testing)
SELECT * FROM vw_CTPNHAP;
SELECT * FROM vw_CTPNHAP_VT;
SELECT * FROM vw_CTPNHAP_VT_PN;
SELECT * FROM vw_CTPNHAP_VT_PN_DH;
SELECT * FROM vw_CTPNHAP_loc;
SELECT * FROM vw_CTPNHAP_VT_loc;
SELECT * FROM vw_CTPXUAT;
SELECT * FROM vw_CTPXUAT_VT;
SELECT * FROM vw_CTPXUAT_VT_PX;
GO
CREATE FUNCTION fn_ThongKeSLDatTheoNhaCungCap()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        DH.MaNCC,
        SUM(CTDH.SLDat) AS TongSoLuongDat
    FROM DONDATHANG DH
    JOIN CTDATHANG CTDH ON DH.SoDH = CTDH.SoDH
    GROUP BY DH.MaNCC
);
GO

-- Question 2: Function fn_LayThongTinNhaCungCap
CREATE FUNCTION fn_LayThongTinNhaCungCap(@MaNhaCC VARCHAR(5))
RETURNS INT
AS
BEGIN
    DECLARE @TongSoHoaDon INT;
    SELECT @TongSoHoaDon = COUNT(*)
    FROM DONDATHANG
    WHERE MaNCC = @MaNhaCC;
    RETURN @TongSoHoaDon;
END;
GO

-- Question 3: Function fn_LayThongTinPhieuNhap
CREATE FUNCTION fn_LayThongTinPhieuNhap(@SoPN VARCHAR(5))
RETURNS FLOAT
AS
BEGIN
    DECLARE @TongTien FLOAT;
    SELECT @TongTien = SUM(SLNhap * DGNhap)
    FROM CTPHIEUNHAP
    WHERE SoPN = @SoPN;
    RETURN ISNULL(@TongTien, 0);
END;
GO

-- Question 4: Function fn_LayThongTinPhieuXuat
CREATE FUNCTION fn_LayThongTinPhieuXuat(@year INT)
RETURNS INT
AS
BEGIN
    DECLARE @TongSoPhieuXuat INT;
    SELECT @TongSoPhieuXuat = COUNT(*)
    FROM PHIEUXUAT
    WHERE YEAR(NgayXuat) = @year;
    RETURN @TongSoPhieuXuat;
END;
GO

-- Question 5: Function fn_LayThongTinVatTuTheoPhieuXuat
CREATE FUNCTION fn_LayThongTinVatTuTheoPhieuXuat()
RETURNS TABLE
AS
RETURN
(
    SELECT 
        SoPX,
        COUNT(MaVT) AS SoVatTu
    FROM CTPHIEUXUAT
    GROUP BY SoPX
);
GO

-- Test fn_ThongKeSLDatTheoNhaCungCap
SELECT * FROM fn_ThongKeSLDatTheoNhaCungCap();
GO

-- Test fn_LayThongTinNhaCungCap
SELECT 'C01' AS MaNhaCC, dbo.fn_LayThongTinNhaCungCap('C01') AS TongSoHoaDon
UNION
SELECT 'C02' AS MaNhaCC, dbo.fn_LayThongTinNhaCungCap('C02') AS TongSoHoaDon;
GO

-- Test fn_LayThongTinPhieuNhap
SELECT 'N001' AS SoPN, dbo.fn_LayThongTinPhieuNhap('N001') AS TongTien
UNION
SELECT 'N002' AS SoPN, dbo.fn_LayThongTinPhieuNhap('N002') AS TongTien;
GO

-- Test fn_LayThongTinPhieuXuat
SELECT 2007 AS Nam, dbo.fn_LayThongTinPhieuXuat(2007) AS TongSoPhieuXuat
UNION
SELECT 2016 AS Nam, dbo.fn_LayThongTinPhieuXuat(2016) AS TongSoPhieuXuat;
GO

-- Test fn_LayThongTinVatTuTheoPhieuXuat
SELECT * FROM fn_LayThongTinVatTuTheoPhieuXuat();
GO